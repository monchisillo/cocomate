"""
Stellar Grid Bot - Motor Principal
Coloca y gestiona órdenes de compra/venta en el DEX de Stellar
"""

import asyncio
import logging
import time
from decimal import Decimal, ROUND_DOWN
from typing import Optional
from datetime import datetime

from stellar_sdk import (
    Server, Keypair, TransactionBuilder, Network, Asset,
    ManageBuyOffer, ManageSellOffer
)
from stellar_sdk.exceptions import NotFoundError, BadRequestError

from .config_loader import BotConfig
from .db_manager import DatabaseManager
from .price_feed import PriceFeed
from .order_manager import OrderManager
from .notifier import Notifier

logger = logging.getLogger("grid_bot")


class GridBot:
    """
    Grid Bot para el DEX nativo de Stellar.
    Estrategia: coloca N órdenes de compra y N de venta
    en rangos de precio equidistantes entre price_min y price_max.
    """

    def __init__(self, config: BotConfig):
        self.config = config
        self.running = False
        self.cycle_count = 0

        # Keypair del bot
        self.keypair = Keypair.from_secret(config.secret_key)
        self.public_key = self.keypair.public_key
        logger.info(f"🔑 Wallet: {self.public_key}")

        # Horizon server
        self.server = Server(horizon_url=config.horizon_url)
        self.network_passphrase = (
            Network.PUBLIC_NETWORK_PASSPHRASE
            if config.network == "mainnet"
            else Network.TESTNET_NETWORK_PASSPHRASE
        )

        # Assets
        self.base_asset = self._parse_asset(config.base_asset)
        self.quote_asset = self._parse_asset(config.quote_asset)

        # Componentes
        self.db = DatabaseManager(config.db_path)
        self.price_feed = PriceFeed(self.server, self.base_asset, self.quote_asset)
        self.order_manager = OrderManager(
            self.server, self.keypair, self.network_passphrase,
            self.base_asset, self.quote_asset, self.db
        )
        self.notifier = Notifier(config.telegram_token, config.telegram_chat_id)

        # Calcular niveles del grid
        self.grid_levels = self._calculate_grid_levels()
        logger.info(f"📊 Grid: {len(self.grid_levels)} niveles entre "
                    f"{config.price_min} y {config.price_max}")

    def _parse_asset(self, asset_str: str) -> Asset:
        if asset_str.upper() == "XLM":
            return Asset.native()
        parts = asset_str.split(":")
        if len(parts) != 2:
            raise ValueError(f"Formato de asset inválido: {asset_str}. Usar CODE:ISSUER")
        return Asset(parts[0], parts[1])

    def _calculate_grid_levels(self) -> list[Decimal]:
        """Calcula precios equidistantes entre price_min y price_max."""
        levels = []
        price_min = Decimal(str(self.config.price_min))
        price_max = Decimal(str(self.config.price_max))
        n = self.config.grid_levels

        step = (price_max - price_min) / Decimal(str(n - 1))
        for i in range(n):
            level = (price_min + step * i).quantize(Decimal("0.0000001"), rounding=ROUND_DOWN)
            levels.append(level)

        return levels

    def get_order_amount(self) -> Decimal:
        """Cantidad de base asset por orden."""
        return Decimal(str(self.config.order_amount)).quantize(
            Decimal("0.0000001"), rounding=ROUND_DOWN
        )

    async def initialize(self):
        """Verifica balance y cancela órdenes previas del bot si existen."""
        logger.info("🚀 Inicializando bot...")
        self.db.initialize()

        # Verificar cuenta
        try:
            account = self.server.accounts().account_id(self.public_key).call()
            balances = {b["asset_type"]: b for b in account["balances"]}
            logger.info(f"💰 Balances: {balances}")
        except NotFoundError:
            raise RuntimeError(f"Cuenta {self.public_key} no encontrada en {self.config.network}")

        # Cancelar órdenes previas del bot
        if self.config.cancel_orders_on_start:
            logger.info("🧹 Cancelando órdenes previas...")
            await self.order_manager.cancel_all_bot_orders()

        await self.notifier.send(
            f"🤖 *Stellar Grid Bot iniciado*\n"
            f"Par: `{self.config.base_asset}/{self.config.quote_asset}`\n"
            f"Niveles: {self.config.grid_levels}\n"
            f"Rango: {self.config.price_min} - {self.config.price_max}\n"
            f"Red: {self.config.network}"
        )

    async def run(self):
        """Loop principal del bot."""
        self.running = True
        await self.initialize()

        logger.info(f"⚙️  Ciclo cada {self.config.poll_interval}s")

        while self.running:
            try:
                await self._run_cycle()
                self.cycle_count += 1
                await asyncio.sleep(self.config.poll_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Error en ciclo: {e}", exc_info=True)
                await self.notifier.send(f"⚠️ Error: {e}")
                await asyncio.sleep(self.config.poll_interval * 2)

        await self._shutdown()

    async def _run_cycle(self):
        """Un ciclo del grid: verificar precio, colocar/ajustar órdenes."""
        current_price = await self.price_feed.get_current_price()
        if current_price is None:
            logger.warning("⚠️  No se pudo obtener precio, saltando ciclo")
            return

        logger.info(f"💹 Precio actual: {current_price}")
        self.db.record_price(float(current_price))

        # Órdenes activas en Stellar
        active_offers = await self.order_manager.get_active_offers()
        active_offer_ids = {o["id"] for o in active_offers}

        # Órdenes que tenemos en DB
        db_orders = self.db.get_open_orders()
        db_offer_ids = {str(o["offer_id"]) for o in db_orders if o["offer_id"]}

        # Detectar órdenes ejecutadas (en DB pero no en Stellar)
        executed_ids = db_offer_ids - active_offer_ids
        for eid in executed_ids:
            await self._handle_executed_order(eid, current_price)

        # Colocar órdenes faltantes del grid
        await self._place_missing_orders(current_price, active_offers)

        logger.info(
            f"✅ Ciclo #{self.cycle_count} OK | "
            f"Órdenes activas: {len(active_offers)} | "
            f"Precio: {current_price}"
        )

    async def _handle_executed_order(self, offer_id: str, current_price: Decimal):
        """Cuando una orden se ejecuta, colocar la orden contraria."""
        order = self.db.get_order_by_offer_id(offer_id)
        if not order:
            return

        logger.info(f"🎯 Orden ejecutada: {offer_id} ({order['side']} @ {order['price']})")
        self.db.mark_order_executed(offer_id, float(current_price))

        profit = self._calculate_profit(order)
        self.db.record_trade(order, float(current_price), profit)

        # Colocar orden contraria
        grid_step = self._get_grid_step()
        if order["side"] == "buy":
            new_price = Decimal(str(order["price"])) + grid_step
            new_side = "sell"
        else:
            new_price = Decimal(str(order["price"])) - grid_step
            new_side = "buy"

        # Solo colocar si está dentro del rango
        if Decimal(str(self.config.price_min)) <= new_price <= Decimal(str(self.config.price_max)):
            await self.order_manager.place_order(new_side, new_price, self.get_order_amount())
            await self.notifier.send(
                f"🔄 Orden ejecutada & nueva colocada\n"
                f"Ejecutada: {order['side']} @ {order['price']}\n"
                f"Nueva: {new_side} @ {new_price}\n"
                f"P&L estimado: {profit:.7f}"
            )

    def _get_grid_step(self) -> Decimal:
        """Tamaño del paso del grid."""
        price_min = Decimal(str(self.config.price_min))
        price_max = Decimal(str(self.config.price_max))
        return (price_max - price_min) / Decimal(str(self.config.grid_levels - 1))

    def _calculate_profit(self, order: dict) -> float:
        """Estimado de profit por operación (sin fees)."""
        step = float(self._get_grid_step())
        amount = float(self.config.order_amount)
        return step * amount

    async def _place_missing_orders(self, current_price: Decimal, active_offers: list):
        """Coloca órdenes del grid que no existen aún."""
        existing_prices = {
            Decimal(str(o.get("price", 0))).quantize(Decimal("0.0000001"))
            for o in active_offers
        }

        orders_placed = 0
        for level_price in self.grid_levels:
            if level_price in existing_prices:
                continue

            # Órdenes de compra debajo del precio actual, de venta arriba
            if level_price < current_price:
                side = "buy"
            elif level_price > current_price:
                side = "sell"
            else:
                continue  # Exactamente en el precio actual, omitir

            # No colocar demasiadas órdenes por ciclo
            if orders_placed >= self.config.max_orders_per_cycle:
                break

            success = await self.order_manager.place_order(
                side, level_price, self.get_order_amount()
            )
            if success:
                orders_placed += 1
                await asyncio.sleep(0.5)  # Evitar spam de transacciones

    async def _shutdown(self):
        logger.info("🛑 Deteniendo bot...")
        if self.config.cancel_orders_on_stop:
            logger.info("🧹 Cancelando órdenes al apagar...")
            await self.order_manager.cancel_all_bot_orders()
        await self.notifier.send("🛑 *Grid Bot detenido*")
        logger.info("👋 Bot detenido correctamente")

    def stop(self):
        self.running = False
