"""
Gestión de órdenes en el DEX nativo de Stellar.
Usa manageBuyOffer y manageSellOffer para interactuar con el libro de órdenes on-chain.
"""

import logging
from decimal import Decimal, ROUND_DOWN
from typing import Optional, List

from stellar_sdk import (
    Server, Keypair, TransactionBuilder, Network, Asset,
    ManageBuyOffer, ManageSellOffer
)
from stellar_sdk.exceptions import BadRequestError, NotFoundError

from .db_manager import DatabaseManager

logger = logging.getLogger("grid_bot.orders")

# Fee por transacción en Stellar (0.00001 XLM base, puede aumentarse para prioridad)
BASE_FEE = 100  # en stroops (1 XLM = 10,000,000 stroops)


class OrderManager:
    def __init__(
        self,
        server: Server,
        keypair: Keypair,
        network_passphrase: str,
        base_asset: Asset,
        quote_asset: Asset,
        db: DatabaseManager,
        dry_run: bool = False,
    ):
        self.server = server
        self.keypair = keypair
        self.network_passphrase = network_passphrase
        self.base_asset = base_asset
        self.quote_asset = quote_asset
        self.db = db
        self.dry_run = dry_run

    def _format_price(self, price: Decimal) -> str:
        """Formatea precio con 7 decimales para Stellar."""
        return str(price.quantize(Decimal("0.0000001"), rounding=ROUND_DOWN))

    def _format_amount(self, amount: Decimal) -> str:
        """Formatea cantidad con 7 decimales para Stellar."""
        return str(amount.quantize(Decimal("0.0000001"), rounding=ROUND_DOWN))

    async def place_order(self, side: str, price: Decimal, amount: Decimal) -> bool:
        """
        Coloca una orden de compra o venta en el DEX de Stellar.

        En el DEX de Stellar:
        - manageSellOffer: vender base_asset a cambio de quote_asset
        - manageBuyOffer: comprar base_asset usando quote_asset

        Returns True si exitoso.
        """
        price_str = self._format_price(price)
        amount_str = self._format_amount(amount)

        if self.dry_run:
            logger.info(f"[DRY RUN] Colocando {side} @ {price_str} | amount: {amount_str}")
            self.db.save_order("dry_run_" + str(price), side, float(price), float(amount))
            return True

        try:
            account = self.server.load_account(self.keypair.public_key)
            builder = TransactionBuilder(
                source_account=account,
                network_passphrase=self.network_passphrase,
                base_fee=BASE_FEE,
            )
            builder.set_timeout(30)

            if side == "sell":
                # Vender base_asset, recibir quote_asset
                builder.append_manage_sell_offer_op(
                    selling=self.base_asset,
                    buying=self.quote_asset,
                    amount=amount_str,
                    price=price_str,
                    offer_id=0,  # 0 = nueva oferta
                )
            elif side == "buy":
                # Comprar base_asset, pagar con quote_asset
                # amount en manageBuyOffer es la cantidad de base_asset que quiero
                builder.append_manage_buy_offer_op(
                    selling=self.quote_asset,
                    buying=self.base_asset,
                    amount=amount_str,
                    price=price_str,
                    offer_id=0,
                )
            else:
                raise ValueError(f"Side inválido: {side}")

            tx = builder.build()
            tx.sign(self.keypair)
            response = self.server.submit_transaction(tx)

            # Extraer offer_id de la respuesta
            offer_id = self._extract_offer_id(response, side)
            if offer_id:
                self.db.save_order(offer_id, side, float(price), float(amount))
                logger.info(f"✅ Orden colocada: {side} @ {price_str} | ID: {offer_id}")
                return True
            else:
                logger.warning(f"⚠️  Orden enviada pero no se pudo extraer offer_id")
                return False

        except BadRequestError as e:
            logger.error(f"❌ Error en transacción ({side} @ {price_str}): {e.extras}")
            return False
        except Exception as e:
            logger.error(f"❌ Error inesperado colocando orden: {e}", exc_info=True)
            return False

    def _extract_offer_id(self, response: dict, side: str) -> Optional[str]:
        """Extrae el offer_id de la respuesta de Horizon."""
        try:
            result_meta = response.get("result_meta_xdr", "")
            # Buscar en result_record
            result = response.get("result_xdr", "")

            # Método alternativo: buscar en los effects
            effects_url = response.get("_links", {}).get("transaction", {}).get("href", "")

            # Extraer de envelope_xdr procesado
            # El offer_id se puede encontrar en los operation results
            envelope = response.get("envelope_xdr", "")

            # Intentar desde _embedded si existe
            embedded = response.get("_embedded", {})

            # Si la transacción fue exitosa, buscar en los records de operaciones
            # Simplificación: usar hash de tx + timestamp como ID temporal
            tx_hash = response.get("hash", "")
            if tx_hash:
                return f"{side}_{tx_hash[:16]}"

            return None
        except Exception:
            return None

    async def cancel_order(self, offer_id: str, side: str) -> bool:
        """Cancela una oferta específica en el DEX (offer_id=0 + mismo precio cancela)."""
        if self.dry_run:
            logger.info(f"[DRY RUN] Cancelando orden {offer_id}")
            self.db.mark_order_cancelled(offer_id)
            return True

        try:
            account = self.server.load_account(self.keypair.public_key)
            builder = TransactionBuilder(
                source_account=account,
                network_passphrase=self.network_passphrase,
                base_fee=BASE_FEE,
            )
            builder.set_timeout(30)

            # Para cancelar: amount=0 con el offer_id original
            if side == "sell":
                builder.append_manage_sell_offer_op(
                    selling=self.base_asset,
                    buying=self.quote_asset,
                    amount="0",
                    price="1",
                    offer_id=int(offer_id) if offer_id.isdigit() else 0,
                )
            else:
                builder.append_manage_buy_offer_op(
                    selling=self.quote_asset,
                    buying=self.base_asset,
                    amount="0",
                    price="1",
                    offer_id=int(offer_id) if offer_id.isdigit() else 0,
                )

            tx = builder.build()
            tx.sign(self.keypair)
            self.server.submit_transaction(tx)

            self.db.mark_order_cancelled(offer_id)
            logger.info(f"🗑️  Orden cancelada: {offer_id}")
            return True

        except Exception as e:
            logger.error(f"❌ Error cancelando orden {offer_id}: {e}")
            return False

    async def cancel_all_bot_orders(self):
        """Cancela todas las órdenes abiertas de esta cuenta en el DEX."""
        try:
            offers = self.server.offers().for_account(self.keypair.public_key).limit(200).call()
            records = offers.get("_embedded", {}).get("records", [])

            if not records:
                logger.info("ℹ️  No hay órdenes activas para cancelar")
                self.db.cancel_all_open_orders()
                return

            logger.info(f"🧹 Cancelando {len(records)} órdenes...")

            # Cancelar en lotes de 10 (límite de operaciones por tx en Stellar)
            for i in range(0, len(records), 10):
                batch = records[i:i+10]
                await self._cancel_batch(batch)

            self.db.cancel_all_open_orders()
            logger.info("✅ Todas las órdenes canceladas")

        except Exception as e:
            logger.error(f"❌ Error cancelando todas las órdenes: {e}")

    async def _cancel_batch(self, offers: list):
        """Cancela un lote de ofertas en una sola transacción."""
        if self.dry_run:
            return

        try:
            account = self.server.load_account(self.keypair.public_key)
            builder = TransactionBuilder(
                source_account=account,
                network_passphrase=self.network_passphrase,
                base_fee=BASE_FEE * len(offers),
            )
            builder.set_timeout(60)

            for offer in offers:
                offer_id = int(offer["id"])
                selling_asset = offer.get("selling", {})
                asset_type = selling_asset.get("asset_type", "")

                if "credit" in asset_type:
                    builder.append_manage_sell_offer_op(
                        selling=Asset(selling_asset["asset_code"], selling_asset["asset_issuer"]),
                        buying=Asset.native(),
                        amount="0",
                        price="1",
                        offer_id=offer_id,
                    )
                else:
                    builder.append_manage_sell_offer_op(
                        selling=Asset.native(),
                        buying=Asset(
                            offer.get("buying", {}).get("asset_code", "XLM"),
                            offer.get("buying", {}).get("asset_issuer", "")
                        ),
                        amount="0",
                        price="1",
                        offer_id=offer_id,
                    )

            tx = builder.build()
            tx.sign(self.keypair)
            self.server.submit_transaction(tx)

        except Exception as e:
            logger.error(f"❌ Error en lote de cancelaciones: {e}")

    async def get_active_offers(self) -> List[dict]:
        """Obtiene todas las ofertas activas de esta cuenta en el DEX."""
        try:
            response = (
                self.server.offers()
                .for_account(self.keypair.public_key)
                .limit(200)
                .call()
            )
            records = response.get("_embedded", {}).get("records", [])

            # Enriquecer con side (buy/sell) para facilitar la lógica
            offers = []
            for r in records:
                selling = r.get("selling", {})
                buying = r.get("buying", {})

                # Si el bot vende base_asset → es una orden "sell"
                selling_is_base = (
                    selling.get("asset_type") == "native"
                    if self.base_asset.is_native()
                    else selling.get("asset_code") == self.base_asset.code
                )

                r["_side"] = "sell" if selling_is_base else "buy"
                offers.append(r)

            return offers

        except Exception as e:
            logger.error(f"❌ Error obteniendo ofertas activas: {e}")
            return []
