#!/usr/bin/env python3
"""
Stellar Grid Bot - Punto de entrada principal
Uso: python main.py [--config config/config.yaml] [--dry-run] [--status]
"""

import asyncio
import argparse
import logging
import signal
import sys
import os

# Asegurar que el directorio raíz esté en el path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bot.config_loader import load_config
from bot.grid_bot import GridBot
from bot.db_manager import DatabaseManager


def setup_logging(level: str = "INFO"):
    """Configura el sistema de logging con colores."""
    log_level = getattr(logging, level.upper(), logging.INFO)

    # Formato con colores para la terminal
    class ColorFormatter(logging.Formatter):
        COLORS = {
            "DEBUG": "\033[36m",    # cyan
            "INFO": "\033[32m",     # green
            "WARNING": "\033[33m",  # yellow
            "ERROR": "\033[31m",    # red
            "CRITICAL": "\033[35m", # magenta
        }
        RESET = "\033[0m"

        def format(self, record):
            color = self.COLORS.get(record.levelname, self.RESET)
            record.levelname = f"{color}{record.levelname:8}{self.RESET}"
            return super().format(record)

    # Handler para consola
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(ColorFormatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S"
    ))

    # Handler para archivo
    os.makedirs("logs", exist_ok=True)
    file_handler = logging.FileHandler("logs/grid_bot.log", encoding="utf-8")
    file_handler.setFormatter(logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))

    # Configurar root logger
    root_logger = logging.getLogger("grid_bot")
    root_logger.setLevel(log_level)
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)


def print_banner():
    banner = """
\033[36m╔══════════════════════════════════════════════════════╗
║         🌟 STELLAR GRID BOT v1.0.0 🌟               ║
║      DEX nativo · Sin custodia · On-chain            ║
╚══════════════════════════════════════════════════════╝\033[0m
"""
    print(banner)


def show_status(config_path: str):
    """Muestra el estado actual del bot desde la DB."""
    try:
        config = load_config(config_path)
        db = DatabaseManager(config.db_path)
        summary = db.get_summary()

        print("\n📊 ESTADO DEL BOT")
        print("=" * 40)
        print(f"  Órdenes abiertas : {summary['open_orders']}")
        print(f"  Total trades     : {summary['trade_count']}")
        print(f"  Profit total     : {summary['total_profit']:.7f}")
        print(f"  Último precio    : {summary['last_price']}")
        print("=" * 40)

        recent = db.get_recent_trades(5)
        if recent:
            print("\n🔄 Últimos 5 trades:")
            for t in recent:
                sign = "+" if t["profit"] > 0 else ""
                print(f"  {t['side']:4} | {t['entry_price']:.6f} → {t['exit_price']:.6f}"
                      f" | P&L: {sign}{t['profit']:.7f}")
    except Exception as e:
        print(f"❌ Error al obtener status: {e}")


async def main():
    parser = argparse.ArgumentParser(
        description="Stellar Grid Bot - Bot de trading para el DEX de Stellar",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ejemplos:
  python main.py                          # Iniciar con config por defecto
  python main.py --config mi_config.yaml  # Config personalizada
  python main.py --dry-run                # Modo simulación
  python main.py --status                 # Ver estado actual
  python main.py --log-level DEBUG        # Modo verbose
        """
    )

    parser.add_argument(
        "--config", default="config/config.yaml",
        help="Ruta al archivo de configuración YAML"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Modo simulación: no envía transacciones reales"
    )
    parser.add_argument(
        "--status", action="store_true",
        help="Muestra el estado actual y sale"
    )
    parser.add_argument(
        "--log-level", default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Nivel de logging"
    )
    parser.add_argument(
        "--cancel-all", action="store_true",
        help="Cancela todas las órdenes activas y sale"
    )

    args = parser.parse_args()
    setup_logging(args.log_level)
    print_banner()

    logger = logging.getLogger("grid_bot.main")

    # Solo mostrar status
    if args.status:
        show_status(args.config)
        return

    # Cargar configuración
    try:
        config = load_config(args.config)
        if args.dry_run:
            config.dry_run = True
            logger.info("🧪 Modo DRY RUN activado - no se enviarán transacciones reales")
    except Exception as e:
        logger.error(f"❌ Error de configuración: {e}")
        sys.exit(1)

    # Instanciar bot
    bot = GridBot(config)

    # Solo cancelar órdenes
    if args.cancel_all:
        logger.info("🧹 Cancelando todas las órdenes...")
        await bot.order_manager.cancel_all_bot_orders()
        logger.info("✅ Hecho")
        return

    # Manejar señales del sistema (Ctrl+C, SIGTERM)
    loop = asyncio.get_event_loop()

    def shutdown_handler(sig, frame):
        logger.info(f"\n⚠️  Señal {sig} recibida, deteniendo bot...")
        bot.stop()

    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)

    # Iniciar el bot
    try:
        await bot.run()
    except Exception as e:
        logger.critical(f"💥 Error fatal: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
